# Natural-Language-Processing
Python utility to read in raw data from a file or URL, and delivery valuable information about its context.
