from NLTK_Features.GUI import *


#Lexical diversity of text, not used yet   
##def lexical_diversity(my_text_data):
##    word_count = len(my_text_data)
##    vocab_size = len(set(my_text_data))
##    diversity_score = vocab_size / word_count
##    return diversity_score
def main():
    #First Menu
    #demo()
    #createWidgets()
    gui_menu()

if __name__ == "__main__":
    main()
